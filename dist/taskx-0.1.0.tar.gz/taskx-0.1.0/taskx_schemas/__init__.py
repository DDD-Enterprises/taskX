"""TaskX schema files package.

This package contains JSON Schema files for TaskX validation.
Schemas are accessed via importlib.resources, not filesystem paths.
"""

__version__ = "1.0.0"
