"""Template assets for TaskX project setup and directive packs."""
