"""TaskX - Minimal Task Packet Lifecycle System."""

__version__ = "0.1.3"
