"""Compliance gate module."""

from .gate import run_allowlist_gate

__all__ = ["run_allowlist_gate"]
