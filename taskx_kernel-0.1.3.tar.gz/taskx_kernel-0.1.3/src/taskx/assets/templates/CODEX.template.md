# CODEX Instructions

<!-- TASKX:BEGIN -->
(disabled)
<!-- TASKX:END -->
<!-- CHATX:BEGIN -->
(disabled)
<!-- CHATX:END -->

Agent-specific rules are inserted in sentinel blocks only.
