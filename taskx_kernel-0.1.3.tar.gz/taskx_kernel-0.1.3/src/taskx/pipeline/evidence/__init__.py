"""Evidence collector module."""

from taskx.pipeline.evidence.collector import collect_evidence

__all__ = ["collect_evidence"]
