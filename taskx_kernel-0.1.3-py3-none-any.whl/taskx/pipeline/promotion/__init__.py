"""Promotion gate module."""

from .gate import promote_run

__all__ = ["promote_run"]
