"""Project initialization and directive pack toggles."""

