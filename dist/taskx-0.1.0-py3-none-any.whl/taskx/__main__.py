"""TaskX CLI entrypoint for python -m taskx."""

from taskx.cli import cli

if __name__ == "__main__":
    cli()
