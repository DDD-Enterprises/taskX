# Project Instructions

<!-- TASKX:BEGIN -->
(disabled)
<!-- TASKX:END -->
<!-- CHATX:BEGIN -->
(disabled)
<!-- CHATX:END -->

Project-level instructions are maintained in sentinel blocks above.
