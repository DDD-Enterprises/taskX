"""Safety helpers for guarded TaskX operations."""

from taskx.safety.wip_rescue import write_rescue_patch

__all__ = ["write_rescue_patch"]
